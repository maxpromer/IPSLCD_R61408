#include "stm32f10x.h"


void ADC_Configuration(void);
u16 ADC_Filter(void);

