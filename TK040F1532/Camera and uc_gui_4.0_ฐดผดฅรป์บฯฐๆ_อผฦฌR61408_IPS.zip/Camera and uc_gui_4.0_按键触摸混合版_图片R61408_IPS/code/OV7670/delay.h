#ifndef _OV7670_DELAY
#define _OV7670_DELAY

//��ʱ����
void OV7670_delay_us(unsigned int time);
void OV7670_delay_ms(unsigned int time);


#endif

