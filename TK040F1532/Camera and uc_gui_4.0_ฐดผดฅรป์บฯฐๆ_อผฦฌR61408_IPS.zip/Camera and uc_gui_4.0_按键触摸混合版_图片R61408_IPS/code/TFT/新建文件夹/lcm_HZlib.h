#ifndef  _LCM_HZ_LIB_
#define  _LCM_HZ_LIB_

extern const unsigned char HZ16_16lib[][16*2];

#endif  
