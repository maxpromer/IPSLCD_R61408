#ifndef	_SERIAL_NUM_
#define	_SERIAL_NUM_

#define Serial0_NUM	  0x5D4ff33	  //3
#define Serial1_NUM	  0x34355530
#define Serial2_NUM	  0x43014574

//#define Serial0_NUM	  0x66Aff53	  //5
//#define Serial1_NUM	  0x52548348
//#define Serial2_NUM	  0x87221722
//#define Serial0_NUM	  0x66aff53
//#define Serial1_NUM	  0x52548348
//#define Serial2_NUM	  0x87214537

void checkSerialNUM(void);

#endif

